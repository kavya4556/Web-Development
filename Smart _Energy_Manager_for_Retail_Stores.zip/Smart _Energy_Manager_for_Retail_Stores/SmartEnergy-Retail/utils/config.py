import os
from dotenv import load_dotenv

load_dotenv()

# Device power specifications (watts)
DEVICE_POWER_RATES = {
    "LED Lighting": {"watts_per_sqft": 0.8, "cost_per_watt": 0.0085},
    "AC Units": {"watts_per_sqft": 3.5, "cost_per_watt": 0.0092},
    "Refrigeration": {"watts_per_unit": 1200, "units": 3, "cost_per_watt": 0.0088},
    "Escalators": {"watts_per_unit": 2500, "units": 2, "cost_per_watt": 0.0090},
    "Ventilation": {"watts_per_sqft": 0.4, "cost_per_watt": 0.0085}
}

# Power limits with severity levels
POWER_LIMITS = {
    "LED Lighting": {
        "limit": 10000,       # 10kW limit
        "severity": "warning" # Medium priority
    },
    "AC Units": {
        "limit": 25000,       # 25kW limit 
        "severity": "critical" # High priority (red alerts)
    },
    "Refrigeration": {
        "limit": 5000,        # 5kW limit
        "severity": "warning"
    },
    "Escalators": {
        "limit": 6000,        # 6kW limit
        "severity": "warning"
    },
    "Ventilation": {
        "limit": 3000,       # 3kW limit
        "severity": "warning"
    }
}

# Email configuration (if needed)
EMAIL = os.getenv('GMAIL_ADDRESS')
EMAIL_PASSWORD = os.getenv('GMAIL_APP_PASSWORD')