import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from utils.config import EMAIL, EMAIL_PASSWORD

def send_energy_report(recipient_email, report_data):
    """Sends energy report via Gmail"""
    msg = MIMEMultipart()
    msg['From'] = EMAIL
    msg['To'] = recipient_email
    msg['Subject'] = f"Energy Report {datetime.now().strftime('%Y-%m-%d')}"
    
    html = f"""
    <h2>Retail Store Energy Report</h2>
    <h3>Floor-wise Consumption</h3>
    {report_data['floor_table']}
    <h3>Total Daily Cost: ₹{report_data['total_cost']}</h3>
    <p>Generated on {datetime.now().strftime('%c')}</p>
    """
    
    msg.attach(MIMEText(html, 'html'))
    
    with smtplib.SMTP('smtp.gmail.com', 587) as server:
        server.starttls()
        server.login(EMAIL, EMAIL_PASSWORD)
        server.send_message(msg)