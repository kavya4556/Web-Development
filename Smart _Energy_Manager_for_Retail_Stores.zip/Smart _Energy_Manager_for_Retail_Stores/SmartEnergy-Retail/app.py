        
import streamlit as st
import pandas as pd
import plotly.express as px
from utils.config import DEVICE_POWER_RATES, POWER_LIMITS

# Configure Streamlit
st.set_page_config(
    page_title="Retail Energy Manager",
    layout="wide",
    page_icon="🏬"
)

# Title and Description
st.title("🏬 Smart Energy Manager for Retail Stores")
st.markdown("Monitor and control energy usage across store floors")

# Sidebar Controls
with st.sidebar:
    st.header("⚙️ Device Controls")
    devices_status = {
        "LED Lighting": st.toggle("LED Lighting", True),
        "AC Units": st.toggle("AC Units", True),
        "Refrigeration": st.toggle("Refrigeration", True),
        "Escalators": st.toggle("Escalators", True),
        "Ventilation": st.toggle("Ventilation", True)
    }
    
    st.header("🏢 Store Configuration")
    num_floors = st.slider("Number of Floors", 1, 5, 3)
    floor_area = st.number_input("Floor Area (sq ft)", 500, 10000, 2000)
    
    st.header("⚠️ Power Limits (Watts)")
    power_limits = {
        "LED Lighting": st.number_input("LED Lighting Limit", 1000, 20000, POWER_LIMITS["LED Lighting"]["limit"]),
        "AC Units": st.number_input("AC Units Limit", 5000, 50000, POWER_LIMITS["AC Units"]["limit"]),
        "Refrigeration": st.number_input("Refrigeration Limit", 1000, 10000, POWER_LIMITS["Refrigeration"]["limit"]),
        "Escalators": st.number_input("Escalators Limit", 1000, 15000, POWER_LIMITS["Escalators"]["limit"]),
        "Ventilation": st.number_input("Ventilation Limit", 500, 8000, POWER_LIMITS["Ventilation"]["limit"])
    }

def calculate_energy(floor_num):
    energy = {}
    total_watts = 0
    warnings = []
    
    # Lighting (all floors)
    if devices_status["LED Lighting"]:
        lighting = DEVICE_POWER_RATES["LED Lighting"]["watts_per_sqft"] * floor_area
        if lighting > power_limits["LED Lighting"]:
            warnings.append({
                "floor": floor_num,
                "device": "LED Lighting",
                "consumption": lighting,
                "limit": power_limits["LED Lighting"],
                "severity": POWER_LIMITS["LED Lighting"]["severity"],
                "message": f"Floor {floor_num} Lighting exceeds limit ({lighting/1000:.1f}kW > {power_limits['LED Lighting']/1000:.1f}kW)"
            })
        energy["LED Lighting"] = lighting
        total_watts += lighting
    
    # AC (scaled by floor)
    if devices_status["AC Units"]:
        ac = DEVICE_POWER_RATES["AC Units"]["watts_per_sqft"] * floor_area * (1 + 0.1 * floor_num)
        if ac > power_limits["AC Units"]:
            warnings.append({
                "floor": floor_num,
                "device": "AC Units",
                "consumption": ac,
                "limit": power_limits["AC Units"],
                "severity": POWER_LIMITS["AC Units"]["severity"],
                "message": f"CRITICAL: Floor {floor_num} AC exceeds limit ({ac/1000:.1f}kW > {power_limits['AC Units']/1000:.1f}kW)"
            })
        energy["AC Units"] = ac
        total_watts += ac
    
    # Refrigeration (only ground floor)
    if devices_status["Refrigeration"] and floor_num == 1:
        fridge = DEVICE_POWER_RATES["Refrigeration"]["watts_per_unit"] * DEVICE_POWER_RATES["Refrigeration"]["units"]
        if fridge > power_limits["Refrigeration"]:
            warnings.append({
                "floor": floor_num,
                "device": "Refrigeration",
                "consumption": fridge,
                "limit": power_limits["Refrigeration"],
                "severity": POWER_LIMITS["Refrigeration"]["severity"],
                "message": f"Floor {floor_num} Refrigeration exceeds limit ({fridge/1000:.1f}kW > {power_limits['Refrigeration']/1000:.1f}kW)"
            })
        energy["Refrigeration"] = fridge
        total_watts += fridge
    
    # Escalators (except top floor)
    if devices_status["Escalators"] and floor_num < num_floors:
        escalator = DEVICE_POWER_RATES["Escalators"]["watts_per_unit"] * DEVICE_POWER_RATES["Escalators"]["units"]
        if escalator > power_limits["Escalators"]:
            warnings.append({
                "floor": floor_num,
                "device": "Escalators",
                "consumption": escalator,
                "limit": power_limits["Escalators"],
                "severity": POWER_LIMITS["Escalators"]["severity"],
                "message": f"Floor {floor_num} Escalators exceed limit ({escalator/1000:.1f}kW > {power_limits['Escalators']/1000:.1f}kW)"
            })
        energy["Escalators"] = escalator
        total_watts += escalator
    
    # Ventilation (all floors)
    if devices_status["Ventilation"]:
        vent = DEVICE_POWER_RATES["Ventilation"]["watts_per_sqft"] * floor_area
        if vent > power_limits["Ventilation"]:
            warnings.append({
                "floor": floor_num,
                "device": "Ventilation",
                "consumption": vent,
                "limit": power_limits["Ventilation"],
                "severity": POWER_LIMITS["Ventilation"]["severity"],
                "message": f"Floor {floor_num} Ventilation exceeds limit ({vent/1000:.1f}kW > {power_limits['Ventilation']/1000:.1f}kW)"
            })
        energy["Ventilation"] = vent
        total_watts += vent
    
    return energy, total_watts, warnings

if st.button("📊 Generate Energy Report"):
    energy_data = []
    all_warnings = []
    
    # 1. First create the dataframe
    for floor in range(1, num_floors + 1):
        devices, total_watts, warnings = calculate_energy(floor)
        all_warnings.extend(warnings)
        
        floor_data = {"Floor": f"Floor {floor}"}
        for device, watts in devices.items():
            cost_per_hour = watts * DEVICE_POWER_RATES[device]["cost_per_watt"]
            floor_data[f"{device} (Watts)"] = watts
            floor_data[f"{device} (₹/hr)"] = round(cost_per_hour, 2)
            floor_data[f"{device} Limit"] = power_limits[device]
        
        floor_data["Total Watts"] = total_watts
        floor_data["Total Cost (₹/hr)"] = round(total_watts * 0.0085, 2)
        energy_data.append(floor_data)
    
    df = pd.DataFrame(energy_data)  # This creates the df variable
    
    # 2. Display warnings with severity
    if all_warnings:
        critical_warns = [w for w in all_warnings if w["severity"] == "critical"]
        warning_warns = [w for w in all_warnings if w["severity"] == "warning"]
        
        if critical_warns:
            st.error("## 🔥 Critical Power Alerts")
            for warn in critical_warns:
                st.error(warn["message"])
        
        if warning_warns:
            st.warning("## ⚠️ Power Warnings")
            for warn in warning_warns:
                st.warning(warn["message"])
    
    # 3. Create visualizations
    st.subheader("🔌 Device-wise Power Consumption vs Limits")
    
    # Create comparison chart
    compare_data = []
    for floor in df["Floor"]:
        for device in ["LED Lighting", "AC Units", "Refrigeration", "Escalators", "Ventilation"]:
            if f"{device} (Watts)" in df.columns:
                compare_data.append({
                    "Floor": floor,
                    "Device": device,
                    "Consumption": df[df["Floor"] == floor][f"{device} (Watts)"].values[0],
                    "Limit": df[df["Floor"] == floor][f"{device} Limit"].values[0],
                    "Status": "Normal" if df[df["Floor"] == floor][f"{device} (Watts)"].values[0] <= 
                             df[df["Floor"] == floor][f"{device} Limit"].values[0] else "Exceeded"
                })
    
    compare_df = pd.DataFrame(compare_data)
    
    # Create limit comparison chart with color coding
    fig_limits = px.bar(compare_df, x="Floor", y="Consumption", color="Status",
                       facet_col="Device", 
                       title="Power Consumption vs Limits (Red = Exceeded)",
                       labels={"value": "Watts"},
                       color_discrete_map={"Normal": "#636EFA", "Exceeded": "#EF553B"})
    st.plotly_chart(fig_limits, use_container_width=True)
    
    # Cost Visualization
    st.subheader("💰 Operating Costs")
    cost_cols = [col for col in df.columns if "(₹/hr)" in col]
    fig_cost = px.bar(df, x="Floor", y=cost_cols,
                     title="Hourly Operating Cost by Device",
                     barmode='stack')
    st.plotly_chart(fig_cost, use_container_width=True)
    
    # 4. Create and show the styled dataframe
    st.subheader("📊 Detailed Floor Report")
    
    def highlight_exceeded(row):
        styles = []
        for col in row.index:
            if col.endswith('(Watts)') and f"{col.replace('(Watts)', 'Limit')}" in row:
                if row[col] > row[col.replace('(Watts)', 'Limit')]:
                    styles.append('background-color: #ffcccc')
                else:
                    styles.append('')
            else:
                styles.append('')
        return styles
    
    styled_df = df.style.format({
        "Total Cost (₹/hr)": "₹{:.2f}",
        **{col: "₹{:.2f}" for col in df.columns if "(₹/hr)" in col}
    }).apply(highlight_exceeded, axis=1)
    
    st.dataframe(styled_df)

# Device Specifications
with st.expander("📝 Device Specifications & Limits"):
    specs = pd.DataFrame([
        {
            "Device": device,
            "Spec": f"{DEVICE_POWER_RATES[device].get('watts_per_sqft', DEVICE_POWER_RATES[device].get('watts_per_unit', 0))} {'W/sqft' if 'watts_per_sqft' in DEVICE_POWER_RATES[device] else 'W/unit'}",
            "Current Limit": f"{power_limits[device]}W",
            "Severity": POWER_LIMITS[device]["severity"].title()
        }
        for device in DEVICE_POWER_RATES
    ])
    
    def color_specs(row):
        if row['Severity'] == 'Warning':
            return ['background-color: black'] * len(row)
        elif row['Severity'] == 'Critical':
            return ['background-color: black'] * len(row)
        return [''] * len(row)
    
    st.table(specs.style.apply(color_specs, axis=1))